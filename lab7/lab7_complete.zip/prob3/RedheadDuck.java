package prob1;

public class RedheadDuck extends Duck implements FlyWithWings, Quack {

    @Override
    void display() {
        System.out.println("Displaying Red head");
    }
}
