package prob4;

public interface Property {
    public double computeRent();

    public Address getAddress();
}
